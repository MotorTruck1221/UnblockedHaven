export enum GameState {
  Waiting,
  Running,
}

export enum PlayerSchemeKeys {
  ArrowUp = 38,
  ArrowDown = 40,
  W = 87,
  S = 83,
}
